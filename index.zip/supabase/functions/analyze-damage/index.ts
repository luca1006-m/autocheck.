import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "POST required" }), { status: 405, headers: { ...cors, "Content-Type": "application/json" } });

  const key = Deno.env.get("OPENAI_API_KEY");
  if (!key) return new Response(JSON.stringify({ error: "OPENAI_API_KEY fehlt in den Supabase Secrets." }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } });

  try {
    const body = await req.json();
    const image = String(body.image || "");
    if (!image.startsWith("data:image/")) throw new Error("Kein gültiges Bild übergeben.");

    const model = Deno.env.get("OPENAI_DAMAGE_MODEL") || "gpt-4.1-mini";
    const prompt = `Analysiere das Foto eines möglichen Fahrzeugschadens. Antworte ausschließlich als JSON mit diesen Feldern: type, position, description, low, high, repair, confidence. type soll z.B. Kratzer, Delle, Steinschlag, Lackschaden oder Sonstiges sein. low/high sind realistische unverbindliche Reparaturkosten in EUR als ganze Zahlen. Beschreibe nur, was auf dem Bild erkennbar ist. Keine Schuldfrage, keine rechtliche Bewertung. Wenn der Schaden nicht zuverlässig erkennbar ist, setze confidence auf niedrig und verwende eine breite Kostenspanne.`;

    const r = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model,
        input: [{ role: "user", content: [
          { type: "input_text", text: prompt },
          { type: "input_image", image_url: image, detail: "high" },
        ] }],
      }),
    });
    if (!r.ok) throw new Error(`KI-API Fehler ${r.status}: ${await r.text()}`);
    const data = await r.json();
    const raw = data.output_text || "";
    const jsonText = raw.match(/\{[\s\S]*\}/)?.[0];
    if (!jsonText) throw new Error("Die KI hat kein JSON-Ergebnis geliefert.");
    const out = JSON.parse(jsonText);
    return new Response(JSON.stringify(out), { headers: { ...cors, "Content-Type": "application/json" } });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: String(e?.message || e) }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } });
  }
});
