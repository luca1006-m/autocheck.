import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
serve(async req=>{
  if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
  if(req.method!=='POST')return new Response(JSON.stringify({error:'POST required'}),{status:405,headers:{...cors,'Content-Type':'application/json'}});
  const key=Deno.env.get('OPENAI_API_KEY');
  if(!key)return new Response(JSON.stringify({error:'OPENAI_API_KEY fehlt in den Supabase Secrets.'}),{status:500,headers:{...cors,'Content-Type':'application/json'}});
  try{
    const body=await req.json();const pairs=Array.isArray(body.pairs)?body.pairs.slice(0,4):[];
    if(!pairs.length)throw new Error('Keine Bildpaare übergeben.');
    const content=[{type:'input_text',text:`Vergleiche die folgenden Vorher-/Nachher-Fotos desselben Fahrzeugs. Erkenne nur sichtbare Veränderungen. Beurteile nicht, wer schuld ist, und gib keine rechtliche Bewertung ab. Antworte ausschließlich als JSON: {summary:string,newDamages:number|string,confidence:string,items:[{label:string,isNew:boolean,finding:string,low:number,high:number}]}. low/high sind unverbindliche Reparaturkosten in EUR als ganze Zahlen. Wenn eine Veränderung nicht sicher erkennbar ist, setze isNew=false und confidence entsprechend niedrig.`}];
    for(const p of pairs){
      content.push({type:'input_text',text:`Bereich: ${String(p.label||'unbekannt')}`});
      content.push({type:'input_text',text:'VORHER'});content.push({type:'input_image',image_url:String(p.before),detail:'high'});
      content.push({type:'input_text',text:'NACHHER'});content.push({type:'input_image',image_url:String(p.after),detail:'high'});
    }
    const model=Deno.env.get('OPENAI_DAMAGE_MODEL')||'gpt-4.1-mini';
    const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${key}`},body:JSON.stringify({model,input:[{role:'user',content}]})});
    if(!r.ok)throw new Error(`KI-API Fehler ${r.status}: ${await r.text()}`);
    const data=await r.json();const raw=data.output_text||'';const jsonText=raw.match(/\{[\s\S]*\}/)?.[0];if(!jsonText)throw new Error('Die KI hat kein JSON-Ergebnis geliefert.');
    return new Response(JSON.stringify(JSON.parse(jsonText)),{headers:{...cors,'Content-Type':'application/json'}});
  }catch(e){return new Response(JSON.stringify({error:String(e?.message||e)}),{status:500,headers:{...cors,'Content-Type':'application/json'}})}
});
